package yago.gine.Classes;

public class Pacman {

   private int numVides; // Comencem en 3 vides. Les afegim en el constructor
   private int tempsInvulnerable; // temps d'invulnerabilitat que tindrà el pacman
   private int colPacman; // color Pacman (marró) a l'inici

    private int dirPacman; // 2(baix),4(esq),8(dalt),6(dreta)
   private int posIPacman; // fila on està el pacman
   private int posJPacman; // columna on està el pacman
   private char pacman = '<'; // forma del pacman


    public Pacman(int posIPacman, int posJPacman) {
        this.posIPacman = posIPacman;
        this.posJPacman = posJPacman;
    }


    //<editor-fold desc="Getters i Setters">
    public int getNumVides() {
        return numVides;
    }

    public void setNumVides(int numVides) {
        this.numVides = numVides;
    }

    public int getTempsInvulnerable() {
        return tempsInvulnerable;
    }

    public void setTempsInvulnerable(int tempsInvulnerable) {
        this.tempsInvulnerable = tempsInvulnerable;
    }

    public int getColPacman() {
        return colPacman;
    }

    public void setColPacman(int colPacman) {
        this.colPacman = colPacman;
    }

    public int getDirPacman() {
        return dirPacman;
    }

    public void setDirPacman(int dirPacman) {
        this.dirPacman = dirPacman;
    }

    public int getPosIPacman() {
        return posIPacman;
    }

    public void setPosIPacman(int posIPacman) {
        this.posIPacman = posIPacman;
    }

    public int getPosJPacman() {
        return posJPacman;
    }

    public void setPosJPacman(int posJPacman) {
        this.posJPacman = posJPacman;
    }

    public char getPacman() {
        return pacman;
    }

    public void setPacman(char pacman) {
        this.pacman = pacman;
    }
    //</editor-fold>



    public void canviaAspectePacman(int qMoviments){

        if (dirPacman == 6)
            if (qMoviments % 2 == 0)
                pacman = '<';
            else
                pacman = '-';

        else if (dirPacman == 4)
            if (qMoviments % 2 == 0)
                pacman = '>';
            else
                pacman = '-';

        else if (dirPacman == 2)
            if (qMoviments % 2 == 0)
                pacman = '^';
            else
                pacman = '|';

        else if (dirPacman == 8)
            if (qMoviments % 2 == 0)
                pacman = 'v';
            else
                pacman = '|';



    }

    public Pantalla movimentsPacmanTaulell(Pantalla pt){

        int matriu [][] = pt.getformaPantalla();


        switch (dirPacman) {
            case 6:
                if (matriu[posIPacman][posJPacman + 1] != -1) {

                    matriu[posIPacman][posJPacman] = 0;
                    posJPacman++;
                }
                break;
            case 4:
                if (matriu[posIPacman][posJPacman - 1] != -1) {

                    matriu[posIPacman][posJPacman] = 0;
                    posJPacman--;
                }
                break;
            case 8:
                if (matriu[posIPacman - 1][posJPacman] != -1) {

                    matriu[posIPacman][posJPacman] = 0;
                    posIPacman--;
                }
                break;
            case 2:
                if (matriu[posIPacman + 1][posJPacman] != -1) {

                    matriu[posIPacman][posJPacman] = 0;
                    posIPacman++;
                }
                break;
        }
        if (matriu[posIPacman][posJPacman] == 2) {        // si ens menjem un ou gran
            pt.setTempsOuGran(20);

        }// tenim 20 mossos per menjar-nos els fantasmes



        matriu[posIPacman][posJPacman] = 3;                // posem el pacman en el lloc corresponent al taulell

        pt.setFormaPantalla(matriu);

        return pt;
    }



}
