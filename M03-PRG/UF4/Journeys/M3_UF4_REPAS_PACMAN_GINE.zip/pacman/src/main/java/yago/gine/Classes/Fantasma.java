package yago.gine.Classes;

import java.util.Random;

public class Fantasma {

    int colorFantasma; // color del fantasma
    int dirFantasma; // direcció del fantasma (2,4,6 o 8)
    int posIFantasma; // posició de la fila del fantasma
    int posJFantasma; // posició de la columna del fantasma
    char fantasma = '&'; // aspecte del fantasma: ' & '


    public Fantasma(int colorFantasma, int posIFantasma, int posJFantasma) {
        this.colorFantasma = colorFantasma;
        this.posIFantasma = posIFantasma;
        this.posJFantasma = posJFantasma;
    }


    //<editor-fold desc="Getters Setters">
    public int getColorFantasma() {
        return colorFantasma;
    }

    public void setColorFantasma(int colorFantasma) {
        this.colorFantasma = colorFantasma;
    }

    public int getDirFantasma() {
        return dirFantasma;
    }

    public void setDirFantasma(int dirFantasma) {
        this.dirFantasma = dirFantasma;
    }

    public int getPosIFantasma() {
        return posIFantasma;
    }

    public void setPosIFantasma(int posIFantasma) {
        this.posIFantasma = posIFantasma;
    }

    public int getPosJFantasma() {
        return posJFantasma;
    }

    public void setPosJFantasma(int posJFantasma) {
        this.posJFantasma = posJFantasma;
    }

    public char getFantasma() {
        return fantasma;
    }

    public void setFantasma(char fantasma) {
        this.fantasma = fantasma;
    }
    //</editor-fold>


    public void moureFantasms(Pantalla pt) {

        int taulell[][] = pt.getformaPantalla();

        int dirs[] = new int[]{2, 4, 6, 8};

        Random ran = new Random();




        if (dirFantasma == 6) {
            if (taulell[posIFantasma][posJFantasma + 1] != -1) {      // dreta
                posJFantasma++;


            } else {
                dirFantasma = dirs[ran.nextInt(dirs.length)];
            }
        } else if (dirFantasma == 8) {
            if (taulell[posIFantasma - 1][posJFantasma] != -1) {      // amunt
                posIFantasma--;

            } else {
                dirFantasma = dirs[ran.nextInt(dirs.length)];
            }
        } else if (dirFantasma == 4) {
            if (taulell[posIFantasma][posJFantasma - 1] != -1) {      // esq
                posJFantasma--;

            } else {
                dirFantasma = dirs[ran.nextInt(dirs.length)];
            }
        } else if (dirFantasma == 2) {
            if (taulell[posIFantasma + 1][posJFantasma] != -1) {      // baix
                posIFantasma++;

            } else {
                dirFantasma = dirs[ran.nextInt(dirs.length)];
            }


        }else {


            dirFantasma = dirs[ran.nextInt(dirs.length)];

        }

    }
}
