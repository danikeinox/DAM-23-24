package yago.gine.Classes;

import javax.swing.*;

public class Pantalla {

    private int velocitat;


    private int tempsOuGran;
    private int [ ][ ] formaPantalla;

    static Colors cl = new Colors();


    public Pantalla (){}

    public Pantalla (int velocitat){

        this.velocitat = velocitat;

        this.formaPantalla = creaPantalla(1);

    }

    //<editor-fold desc="GETTER SETTER">
    public int getVelocitat() {
        return velocitat;
    }

    public void setVelocitat(int velocitat) {
        this.velocitat = velocitat;
    }

    public int getTempsOuGran() {
        return tempsOuGran;
    }

    public void setTempsOuGran(int tempsOuGran) {
        this.tempsOuGran = tempsOuGran;
    }

    public int[][] getformaPantalla() {
        return formaPantalla;
    }

    public void setFormaPantalla(int[][] formaPantalla) {
        this.formaPantalla = formaPantalla;
    }
    //</editor-fold>




    // Crea i retorna la pantalla 1 (la mateixa que la del pacman estructurat *
    private int [][] pantalla1 (int[][] pantalla){

        int maxF = pantalla.length, maxC = pantalla[1].length;


        for (int i = 0; i < maxF; i++) {
            for (int j = 0; j < maxC; j++) {


                // POSEM ELS OUS GRANS (@) en les cantonades!!!
                if (i == 2 && j == 2 || i == 2 && j == maxC - 3 || i == maxF - 3 && j == 2 ||
                        i == maxF - 3 && j == maxC - 3)

                    pantalla[i][j] = 2;

                else if (

                        (i >= maxF / 2 - 2 && i <= maxF / 2 + 1) && (j >= maxC / 2 - 2 && j <= maxC - 11)   // posem les parets del mig
                                ||
                                (i >= maxF / 2 - 2 && i <= maxF / 2 + 1 && (j <= 3 || j >= maxC - 4))       // parets laterals del mig esquerra i dreta
                                ||
                                (i == 0 || j == 0 || i == maxF - 1 || j == maxC - 1)                        // parets externes (quadrat marc)
                                ||
                                ((i == 4 || i == maxF - 5) && j > 1 && j < maxC - 2)                        // paret de la fila 4 i maxF-5
                                ||
                                (((j == 6 || j == 8 || j == 15 || j == 17) && i > 5 && i < maxF - 6))       // parets de les columnes 6,8,15 i 17
                                ||
                                ((i == 2 || i == maxF - 3) && j > 3 && j < maxC - 4)                        // parets de la fila 2 i maxF-3

                )

                    pantalla[i][j] = -1;                                         // posem paret


                else if (i == maxF / 2 -5 && j == maxC/2) {

                    pantalla[i][j] = 3;                                         //posem pacman
                }

                else
                    pantalla[i][j] = 1;                                          // la resta posem ous petits (1's)
            }
        }


        return pantalla;


    }

    private int [][] pantalla2 (int[][] pantalla){


        return pantalla;
    }





    // depenent del número numPantalla retornarà la pantalla 1 o la 2
    public int[][] creaPantalla(int numPantalla){


        int pant [][] = new int[20][24];

        if (numPantalla == 1){


            pantalla1(pant);

        } else if (numPantalla == 2) {


            pantalla2(pant);


        }


        return pant;
    
    }




    // conta els punts que queden per 'menjar'
      public int contaPunts(){

        int punts = 0;

          for (int i = 0; i < formaPantalla.length; i++) {

              for (int j = 0; j < formaPantalla[0].length; j++) {

                  if (formaPantalla[i][j] == 1 || formaPantalla[i][j] == 2) {

                      punts++;

                  }
              }
          }

        return punts;

      }


    public void imprimeixPantallaOLD(Pacman pacman, Fantasma f1, Fantasma f2, Fantasma f3, Fantasma f4) {

        String colFant [] = new String[]{ cl.roigN, cl.cyanN, cl.verdN, cl.magentaN};

        // imprimim el taulell
        System.out.println(cl.marroN + "\n\n\n\n\n\t\t\t\t\t\tPAC" + cl.blauC + "MAN!!" + cl.nc);
        System.out.println(cl.blauC + "\t\t\t\t\t\t---" + cl.marroN + "-----\n" + cl.nc);
        for (int i = 0; i < formaPantalla.length; i++) {
            System.out.print("\t\t");
            for (int j = 0; j < formaPantalla[0].length; j++) {

                if (i == f1.posIFantasma && j == f1.posJFantasma){


                    System.out.print(colFant[f1.getColorFantasma()]+" "+f1.getFantasma()+" "+cl.nc);

                } else if (i == f2.posIFantasma && j == f2.posJFantasma) {

                    System.out.print(colFant[f2.getColorFantasma()]+" "+f2.getFantasma()+" "+cl.nc);

                }else if (i == f3.posIFantasma && j == f3.posJFantasma) {

                    System.out.print(colFant[f3.getColorFantasma()]+" "+f3.getFantasma()+" "+cl.nc);

                }else if (i == f4.posIFantasma && j == f4.posJFantasma) {

                    System.out.print(colFant[f4.getColorFantasma()]+" "+f4.getFantasma()+" "+cl.nc);

                } else {

                    if (formaPantalla[i][j] == 1)
                        System.out.print(cl.marroN + " . " + cl.nc);            // ou petit
                    else if (formaPantalla[i][j] == 0)
                        System.out.print("   ");                                // espai en blanc
                    else if (formaPantalla[i][j] == 3) {

                        //if (pacman.getColPacman() == 1) {

                            System.out.print(cl.marro + " "+ pacman.getPacman() + " " + cl.nc);// pacman

                       // }
                    } else if (formaPantalla[i][j] == 2) {
                        System.out.print(cl.blauC + " @ " + cl.nc);// OU GRAN

                    } else if (formaPantalla[i][j] == -1) {
                        if (i == 0 || i == formaPantalla.length - 1 || j == 0 || j == formaPantalla[0].length - 1)
                            System.out.print(cl.verdN + " # " + cl.nc);                            // paret
                        else
                            System.out.print(" # ");                            // paret
                    }

                }



            }
            System.out.println();
        }


        System.out.println("\n\n");
        System.out.println(cl.roigN + "\t\t\tqueden: " + contaPunts() + " punts" + cl.nc);
        System.out.println(cl.blauC + "\t\t\tP) Pausar\tR) Reanudar" + cl.nc);
        System.out.println("\n\n\n\n");
    }



    public void imprimeixPantalla(Pacman pacman, Fantasma f1, Fantasma f2, Fantasma f3, Fantasma f4) {

        String colFant [] = new String[]{ cl.roigN, cl.cyanN, cl.verdN, cl.magentaN};
        String colPac [] = new String[]{ cl.marro, cl.roigN};

        // imprimim el taulell
        System.out.println(cl.marroN + "\n\n\n\n\n\t\t\t\t\t\tPAC" + cl.blauC + "MAN!!" + cl.nc);
        System.out.println(cl.blauC + "\t\t\t\t\t\t---" + cl.marroN + "-----\n" + cl.nc);
        for (int i = 0; i < formaPantalla.length; i++) {
            System.out.print("\t\t");
            for (int j = 0; j < formaPantalla[0].length; j++) {

                if (i == f1.posIFantasma && j == f1.posJFantasma){

                    if (tempsOuGran <=0) {
                        System.out.print(colFant[f1.getColorFantasma()] + " " + f1.getFantasma() + " " + cl.nc);
                    }else{


                        System.out.print(cl.nc + " " + f1.getFantasma() + " " + cl.nc);

                    }

                } else if (i == f2.posIFantasma && j == f2.posJFantasma) {

                    if (tempsOuGran <=0) {
                        System.out.print(colFant[f2.getColorFantasma()] + " " + f2.getFantasma() + " " + cl.nc);
                    }else{


                        System.out.print(cl.nc + " " + f2.getFantasma() + " " + cl.nc);

                    }


                }else if (i == f3.posIFantasma && j == f3.posJFantasma) {

                    if (tempsOuGran <=0) {
                        System.out.print(colFant[f3.getColorFantasma()] + " " + f3.getFantasma() + " " + cl.nc);
                    }else{


                        System.out.print(cl.nc + " " + f3.getFantasma() + " " + cl.nc);

                    }


                }else if (i == f4.posIFantasma && j == f4.posJFantasma) {

                    if (tempsOuGran <=0) {
                        System.out.print(colFant[f4.getColorFantasma()] + " " + f4.getFantasma() + " " + cl.nc);
                    }else{


                        System.out.print(cl.nc + " " + f4.getFantasma() + " " + cl.nc);

                    }


                } else {

                    if (formaPantalla[i][j] == 1)
                        System.out.print(cl.marroN + " . " + cl.nc);            // ou petit
                    else if (formaPantalla[i][j] == 0)
                        System.out.print("   ");                                // espai en blanc
                    else if (formaPantalla[i][j] == 3) {

                        //if (pacman.getColPacman() == 1) {

                        System.out.print(colPac[pacman.getColPacman()] + " "+ pacman.getPacman() + " " + cl.nc);// pacman

                        // }
                    } else if (formaPantalla[i][j] == 2) {
                        System.out.print(cl.blauC + " @ " + cl.nc);// OU GRAN

                    } else if (formaPantalla[i][j] == -1) {
                        if (i == 0 || i == formaPantalla.length - 1 || j == 0 || j == formaPantalla[0].length - 1)
                            System.out.print(cl.verdN + " # " + cl.nc);                            // paret
                        else
                            System.out.print(" # ");                            // paret
                    }

                }



            }
            System.out.println();
        }


        System.out.println("\n\n");
        System.out.println(cl.roigN + "\t\t\tqueden: " + contaPunts() + " punts" + cl.nc);
        System.out.println(cl.roigN + "\t\t\tqueden: " + pacman.getNumVides() + " vides" + cl.nc);
        System.out.println(cl.blauC + "\t\t\tP) Pausar\tR) Reanudar" + cl.nc);
        System.out.println("\n\n\n\n");
    }

    // imprimeix la matriu ja amb els caràcters 'pacman' i fantasmes definits
    // El paràmetre pacman que entra és pq el pacman pot estar en la boca oberta,
    // tancada, cap amunt, avall, dreta o esquerra



}
