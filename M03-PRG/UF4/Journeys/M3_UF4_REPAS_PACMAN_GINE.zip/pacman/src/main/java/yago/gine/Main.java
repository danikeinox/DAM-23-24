package yago.gine;

import yago.gine.Classes.Colors;
import yago.gine.Classes.Fantasma;
import yago.gine.Classes.Pacman;
import yago.gine.Classes.Pantalla;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.util.Scanner;


public class Main {

    static Colors cl = new Colors();

    static int direccio;

    static int tempsOuGran = 0;

    static int numTaulell;

    static Pantalla pantalla = new Pantalla();

    static int velocitat = 500;

    static int qMoviments = 0;

    static String sistemaOperatiu = System.getProperty("os.name");

    static Boolean jocAcabat = false;


    static boolean pausa;

    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) throws InterruptedException {

        do {

            System.out.println("Seleciona el taulell (1/2)");

            numTaulell = scan.nextInt();

        }while (numTaulell > 1 || numTaulell < 1);



        //<editor-fold desc="codi Event Botó">
        Frame f = new Frame("Taulell de control");
        f.setLayout(new FlowLayout());
        f.setSize(500, 100);        // TAMAY DEL FRAME
        Label l = new Label();
        l.setText("Posa ací el ratolí i prem botons dreta o esquera del teclat");
        f.add(l);
        f.setVisible(true);


        // POSEM EL CODI DEL LISTENER (cada cop que premem algun botó)
        KeyListener listener = new KeyListener() {
            @Override
            public void keyPressed(KeyEvent event) {
//                if (espai[maxF - 1][llocNau] == -1) {
//
//                }
                if (event.getKeyCode() == KeyEvent.VK_RIGHT) {      // al prèmer tecla dreta
                    direccio = 6;
                }
                if (event.getKeyCode() == KeyEvent.VK_LEFT) {       // al prèmer la tecla esquerra
                    direccio = 4;
                }
                if (event.getKeyCode() == KeyEvent.VK_UP) {       // al prèmer la tecla AMUNT
                    direccio = 8;
                }
                if (event.getKeyCode() == KeyEvent.VK_DOWN) {       // al prèmer la tecla AVALL
                    direccio = 2;
                }
                if (event.getKeyCode() == KeyEvent.VK_P) {      // al prèmer tecla dreta
                    pausa = true;
                }
                if (event.getKeyCode() == KeyEvent.VK_R) {      // al prèmer tecla dreta
                    pausa = false;
                }
            }

            @Override
            public void keyReleased(KeyEvent event) {
                //       printEventInfo("Key Released", event);
            }

            @Override
            public void keyTyped(KeyEvent event) {
                //      printEventInfo("Key Typed", event);
            }

            private void printEventInfo(String str, KeyEvent e) {
//                System.out.println(str);
//                int code = e.getKeyCode();
//                System.out.println("   Code: " + KeyEvent.getKeyText(code));
//                System.out.println("   Char: " + e.getKeyChar());
//                int mods = e.getModifiersEx();
//                System.out.println("    Mods: "
//                        + KeyEvent.getModifiersExText(mods));
//                System.out.println("    Location: "
//                        + keyboardLocation(e.getKeyLocation()));
//                System.out.println("    Action? " + e.isActionKey());
            }

            private String keyboardLocation(int keybrd) throws InterruptedException {
                switch (keybrd) {
                    case KeyEvent.KEY_LOCATION_RIGHT:

                        // return "Right";

                    case KeyEvent.KEY_LOCATION_LEFT:
                        // canviaPos(false);
                        //   return "Left";

                    case KeyEvent.KEY_LOCATION_NUMPAD:
                        return "NumPad";
                    case KeyEvent.KEY_LOCATION_STANDARD:
                        return "Standard";
                    case KeyEvent.KEY_LOCATION_UNKNOWN:
                    default:
                        return "Unknown";
                }
            }
        };

        // AFEGIM EL listener AL JPANELL CREAT DALT
        f.addKeyListener(listener);


        if (sistemaOperatiu.contains("indows")) {
            //  blauC = roigN = cafeN = purpuraN = colorF = nc = "";          // tristament windows no té colors a la terminal
            System.out.println("DETECTAT SISTEMA OPERATIU WINDOWS");
            System.out.println(" NO FUNCIONARÀ AMB cmd NI POWER SHELL");
            System.out.println("INSTAL·LA LA CONSOLA git bash I EXECUTA DES D'ALLÀ");
            Thread.sleep(7000);

        }


        //</editor-fold>



        pantalla.setFormaPantalla(pantalla.creaPantalla(numTaulell));

        Pacman pacman = new Pacman(pantalla.getformaPantalla().length/2 - 5, pantalla.getformaPantalla()[1].length / 2);

        pacman.setNumVides(3);

        pacman.setColPacman(0);

        pacman.canviaAspectePacman(qMoviments);

        Fantasma f1 = new Fantasma(0, 1,pantalla.getformaPantalla()[0].length-3);

        Fantasma f2 = new Fantasma(1, 1,2);

        Fantasma f3 = new Fantasma(2, 18,2);

        Fantasma f4 = new Fantasma(3, 18,pantalla.getformaPantalla()[0].length-3);

        pantalla.imprimeixPantalla(pacman,f1,f2,f3,f4);

        do {
            // control de la pausa
            if (pausa) {                // si premem la p farem pausa el joc
                Thread.sleep(100);      // hem de frenar el joc encara que sigui 100 ms perquè no acceleri massa
            }

            else {// Si no hi ha pausa continuem el joc


                pantalla.contaPunts();

                pantalla = pacman.movimentsPacmanTaulell(pantalla);

                qMoviments++;

                pacman.setDirPacman(direccio);

                pacman.canviaAspectePacman(qMoviments);

                pantalla.imprimeixPantalla(pacman,f1,f2,f3,f4);


                if (qMoviments > 10){


                    f1.moureFantasms(pantalla);
                    f2.moureFantasms(pantalla);
                    f3.moureFantasms(pantalla);
                    f4.moureFantasms(pantalla);

                }
                if (pantalla.getTempsOuGran() >0 ){

                    pantalla.setTempsOuGran(pantalla.getTempsOuGran()-1);

                }


                for (int i = 0; i < pantalla.getformaPantalla().length; i++) {

                    for (int j = 0; j < pantalla.getformaPantalla()[i].length; j++) {


                        if (pantalla.getformaPantalla()[pacman.getPosIPacman()][pacman.getPosJPacman()] == 2)           // si ens menjem un ou gran
                            tempsOuGran = 20;                                  // tenim 20 mossos per menjar-nos els fantasmes

                        if (pantalla.getformaPantalla()[i][j] == 3 &&           // 3 -> pacman

                                (i == f1.getPosIFantasma() && j == f1.getPosJFantasma() ||
                                        i == f2.getPosIFantasma() && j == f2.getPosJFantasma() ||
                                        i == f3.getPosIFantasma() && j == f3.getPosJFantasma() ||
                                        i == f4.getPosIFantasma() && j == f4.getPosJFantasma()
                                )
                        ) {
                            if (tempsOuGran <= 0) {   // Si el temps de l'Ou Gran encara està vigent, ens podem menjar un fantasma
                                pacman.setNumVides(pacman.getNumVides()-1);

                                pacman.setColPacman(1);

                                pantalla.imprimeixPantalla(pacman,f1,f2,f3,f4);

                                Thread.sleep(1000);

                                pacman.setColPacman(0);

                                if (pacman.getNumVides() <= 0){

                                    jocAcabat = true;


                                }

                            }

                        }

                    }

                }



                if (qMoviments % 25 == 0 && velocitat > 100)      // 100 màxim de retràs. Sinò es buggueja
                    velocitat = velocitat - 30;

                Thread.sleep(velocitat);


            }


        }while (!jocAcabat || pantalla.contaPunts() <= 0);

        pantalla.imprimeixPantalla(pacman,f1,f2,f3,f4);
    }
}